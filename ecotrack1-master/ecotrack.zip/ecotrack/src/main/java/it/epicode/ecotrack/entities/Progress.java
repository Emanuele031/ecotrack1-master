package it.epicode.ecotrack.entities;

import jakarta.persistence.*;
import lombok.*;
import java.util.*;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Progress {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private int level;
    private int score;

    @ElementCollection
    private List<String> badges = new ArrayList<>();

    @OneToMany(cascade = CascadeType.ALL)
    @JoinColumn(name = "progress_id")
    private List<Mission> missions = new ArrayList<>();

    @OneToOne
    private User user;
}


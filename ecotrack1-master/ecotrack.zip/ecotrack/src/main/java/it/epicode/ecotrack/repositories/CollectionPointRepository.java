package it.epicode.ecotrack.repositories;

import it.epicode.ecotrack.entities.CollectionPoint;
import org.springframework.data.jpa.repository.JpaRepository;
public interface CollectionPointRepository extends JpaRepository<CollectionPoint, String> {}


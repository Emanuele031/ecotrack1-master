package it.epicode.ecotrack.repositories;

import it.epicode.ecotrack.entities.Progress;
import org.springframework.data.jpa.repository.JpaRepository;
public interface ProgressRepository extends JpaRepository<Progress, Long> {}


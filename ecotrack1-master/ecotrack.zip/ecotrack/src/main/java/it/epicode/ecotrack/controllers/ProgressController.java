package it.epicode.ecotrack.controllers;

import it.epicode.ecotrack.entities.Progress;
import it.epicode.ecotrack.services.ProgressService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@Tag(name="User Progress", description="Gestione punteggio, missioni, badge, livello")
@RestController
@RequestMapping("/api/progress")
@CrossOrigin
public class ProgressController {

    private final ProgressService progressService;

    public ProgressController(ProgressService progressService) {
        this.progressService = progressService;
    }

    @Operation(summary="Ottiene un progress", description="Ritorna i dati di progress (score, missioni) di un utente (via ID).")
    @GetMapping("/{id}")
    public Progress getProgress(@PathVariable Long id) {
        return progressService.getProgressById(id);
    }

    @Operation(summary="Elenca tutti i progress (debug/admin)")
    @GetMapping
    public List<Progress> allProgress() {
        return progressService.getAllProgress();
    }

    @Operation(summary="Crea o aggiorna un Progress (debug/admin)")
    @PostMapping
    public Progress createOrUpdate(@RequestBody Progress prog) {
        return progressService.saveProgress(prog);
    }

    @Operation(summary="Completa missione", description="Imposta la missione come completata, aggiorna punteggio e livello se necessario")
    @PatchMapping("/{progressId}/complete/{missionId}")
    public Progress completeMission(@PathVariable Long progressId, @PathVariable String missionId) {
        return progressService.completeMission(progressId, missionId);
    }
}

package it.epicode.ecotrack.entities;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Habit {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id; // NON inviarlo nel JSON

    @Column(nullable = false)
    private String text; // Descrizione dell'abitudine

    @Column(nullable = false)
    private String type; // Tipo di abitudine (es. "Trasporto", "Energia", "Riciclo")

    private int impactScore; // Punteggio di sostenibilità associato all'abitudine
}

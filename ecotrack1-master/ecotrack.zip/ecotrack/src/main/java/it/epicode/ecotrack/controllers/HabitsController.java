package it.epicode.ecotrack.controllers;

import it.epicode.ecotrack.entities.Habit;
import it.epicode.ecotrack.services.HabitsService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@Tag(name="Habits", description="Gestione abitudini utente")
@RestController
@RequestMapping("/api/habits")
@CrossOrigin
public class HabitsController {

    private final HabitsService habitsService;
    private static final Logger logger = LoggerFactory.getLogger(HabitsController.class);

    public HabitsController(HabitsService habitsService) {
        this.habitsService = habitsService;
    }

    @Operation(summary="Elenca tutte le abitudini", description="Ritorna la lista di Habit presenti")
    @GetMapping
    public List<Habit> getAllHabits() {
        return habitsService.getAll();
    }

    @Operation(summary="Crea una nuova abitudine")
    @PostMapping
    public ResponseEntity<?> addHabit(@RequestBody Habit habit) {
        logger.info("📥 Richiesta ricevuta: {}", habit);

        // Controlla se ci sono campi vuoti
        if (habit.getText() == null || habit.getText().isBlank()) {
            logger.error("❌ ERRORE: Il campo 'text' è obbligatorio.");
            return ResponseEntity.badRequest().body("Errore: Il campo 'text' è obbligatorio.");
        }
        if (habit.getType() == null || habit.getType().isBlank()) {
            logger.error("❌ ERRORE: Il campo 'type' è obbligatorio.");
            return ResponseEntity.badRequest().body("Errore: Il campo 'type' è obbligatorio.");
        }

        try {
            Habit savedHabit = habitsService.createHabit(habit);
            return ResponseEntity.ok(savedHabit);
        } catch (Exception e) {
            logger.error("❌ ERRORE GENERICO: {}", e.getMessage());
            return ResponseEntity.badRequest().body("Errore durante il salvataggio dell'abitudine.");
        }
    }


    @Operation(summary="Ottieni il punteggio totale di sostenibilità")
    @GetMapping("/score")
    public int getSustainabilityScore() {
        return habitsService.calculateSustainabilityScore();
    }

    @Operation(summary="Ottieni consigli personalizzati basati sulle abitudini")
    @GetMapping("/recommendations")
    public List<String> getRecommendations() {
        return habitsService.getRecommendations();
    }
}

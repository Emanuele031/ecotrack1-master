package it.epicode.ecotrack.controllers;

import it.epicode.ecotrack.entities.User;
import it.epicode.ecotrack.services.LeaderboardService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@Tag(name="Leaderboard", description="Classifica utenti in base al punteggio")
@RestController
@RequestMapping("/api/leaderboard")
@CrossOrigin
public class LeaderboardController {

    private final LeaderboardService lbService;

    public LeaderboardController(LeaderboardService lbService) {
        this.lbService = lbService;
    }

    @Operation(summary="Ottiene la leaderboard", description="Ritorna la lista utenti ordinata per punteggio disc.")
    @GetMapping
    public List<User> getLeaderboard() {
        return lbService.getLeaderboard();
    }
}

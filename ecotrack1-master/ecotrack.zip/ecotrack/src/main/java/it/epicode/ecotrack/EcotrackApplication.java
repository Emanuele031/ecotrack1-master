package it.epicode.ecotrack;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EcotrackApplication {

	public static void main(String[] args) {
		SpringApplication.run(EcotrackApplication.class, args);
	}

}

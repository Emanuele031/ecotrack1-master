package it.epicode.ecotrack.entities;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CollectionPoint {
    @Id
    private String id;
    private String name;
    private double lat;
    private double lng;
    private String description;
    private String category;
}


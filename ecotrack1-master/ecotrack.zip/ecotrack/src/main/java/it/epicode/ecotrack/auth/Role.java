package it.epicode.ecotrack.auth;


public enum Role {
    ROLE_USER,
    ROLE_ADMIN,
    ROLE_SELLER
}

package it.epicode.ecotrack.services;

import it.epicode.ecotrack.entities.Habit;
import it.epicode.ecotrack.repositories.HabitRepository;
import org.springframework.stereotype.Service;
import java.util.ArrayList;
import java.util.List;

@Service
public class HabitsService {
    private final HabitRepository habitRepo;

    public HabitsService(HabitRepository habitRepo) {
        this.habitRepo = habitRepo;
    }

    public List<Habit> getAll() {
        return habitRepo.findAll();
    }

    public Habit createHabit(Habit habit) {
        if (habit.getText() == null || habit.getText().trim().isEmpty()) {
            throw new IllegalArgumentException("Il campo 'text' è obbligatorio.");
        }
        if (habit.getType() == null || habit.getType().trim().isEmpty()) {
            throw new IllegalArgumentException("Il campo 'type' è obbligatorio.");
        }

        int score = assignImpactScore(habit.getText());
        habit.setImpactScore(score);
        return habitRepo.save(habit);
    }


    // Metodo per calcolare il punteggio di sostenibilità totale
    public int calculateSustainabilityScore() {
        List<Habit> habits = habitRepo.findAll();
        int totalScore = 0;

        for (Habit habit : habits) {
            totalScore += habit.getImpactScore();
        }
        return totalScore;
    }

    // Metodo per ottenere consigli personalizzati basati sulle abitudini
    public List<String> getRecommendations() {
        List<Habit> habits = habitRepo.findAll();
        List<String> recommendations = new ArrayList<>();

        for (Habit habit : habits) {
            String text = habit.getText().toLowerCase();
            if (text.contains("auto")) {
                recommendations.add("🚗 Prova a usare i mezzi pubblici almeno 2 volte a settimana!");
            } else if (text.contains("bottiglia")) {
                recommendations.add("💧 Usa una borraccia riutilizzabile per ridurre la plastica!");
            } else if (text.contains("riciclo")) {
                recommendations.add("♻️ Ottimo! Continua a riciclare per un impatto minore.");
            } else if (text.contains("energia")) {
                recommendations.add("💡 Usa lampadine a LED per risparmiare energia!");
            } else {
                recommendations.add("🌱 Continua così! Ogni azione aiuta l'ambiente.");
            }
        }
        return recommendations;
    }

    // Metodo per assegnare un punteggio di impatto in base all'abitudine
    private int assignImpactScore(String habitText) {
        habitText = habitText.toLowerCase();
        if (habitText.contains("auto")) {
            return -10; // Usare l'auto ha un impatto negativo
        } else if (habitText.contains("bici") || habitText.contains("cammino")) {
            return 15; // Andare in bici o camminare ha un impatto positivo
        } else if (habitText.contains("bottiglia")) {
            return -5; // Usare bottiglie di plastica ha un impatto negativo
        } else if (habitText.contains("riciclo")) {
            return 10; // Riciclare ha un impatto positivo
        } else if (habitText.contains("energia")) {
            return 8; // Ridurre il consumo di energia è positivo
        } else {
            return 5; // Altre azioni generiche hanno un impatto leggero
        }
    }
}

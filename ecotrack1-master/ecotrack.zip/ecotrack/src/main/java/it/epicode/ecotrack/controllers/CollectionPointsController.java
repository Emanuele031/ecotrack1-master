package it.epicode.ecotrack.controllers;

import it.epicode.ecotrack.entities.CollectionPoint;
import it.epicode.ecotrack.services.CollectionPointsService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@Tag(name="Collection Points", description="Gestione centri di raccolta e isole ecologiche")
@RestController
@RequestMapping("/api/collection-points")
@CrossOrigin
public class CollectionPointsController {

    private final CollectionPointsService cpService;

    public CollectionPointsController(CollectionPointsService cpService) {
        this.cpService = cpService;
    }

    @Operation(summary="Elenca tutti i punti di raccolta")
    @GetMapping
    public List<CollectionPoint> getAll() {
        return cpService.getAll();
    }

    @Operation(summary="Aggiunge un nuovo centro di raccolta")
    @PostMapping
    public CollectionPoint addPoint(@RequestBody CollectionPoint cp) {
        return cpService.save(cp);
    }
}

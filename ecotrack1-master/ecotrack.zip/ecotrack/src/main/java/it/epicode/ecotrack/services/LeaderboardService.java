package it.epicode.ecotrack.services;


import it.epicode.ecotrack.entities.User;
import it.epicode.ecotrack.repositories.UserRepository;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class LeaderboardService {

    private final UserRepository userRepo;

    public LeaderboardService(UserRepository userRepo) {
        this.userRepo = userRepo;
    }

    public List<User> getLeaderboard() {
        return userRepo.findAll().stream()
                .sorted((u1, u2) -> Integer.compare(u2.getScore(), u1.getScore()))
                .collect(Collectors.toList());
    }
}


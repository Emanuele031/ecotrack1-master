package it.epicode.ecotrack.entities;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Mission {
    @Id
    private String id;
    private String title;
    private String description;
    private int points;
    private boolean completed;
    private String badge;
}


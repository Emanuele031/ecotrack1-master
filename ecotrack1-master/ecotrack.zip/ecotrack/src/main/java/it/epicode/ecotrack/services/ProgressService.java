package it.epicode.ecotrack.services;


import it.epicode.ecotrack.entities.Mission;
import it.epicode.ecotrack.entities.Progress;
import it.epicode.ecotrack.repositories.ProgressRepository;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class ProgressService {
    private final ProgressRepository progRepo;

    public ProgressService(ProgressRepository progRepo) {
        this.progRepo = progRepo;
    }

    public Progress getProgressById(Long id) {
        return progRepo.findById(id).orElse(null);
    }

    public List<Progress> getAllProgress() {
        return progRepo.findAll();
    }

    public Progress saveProgress(Progress progress) {
        return progRepo.save(progress);
    }

    public Progress completeMission(Long progressId, String missionId) {
        Progress p = progRepo.findById(progressId)
                .orElseThrow(() -> new RuntimeException("Progress not found"));

        Mission m = p.getMissions().stream()
                .filter(mi -> mi.getId().equals(missionId))
                .findFirst()
                .orElseThrow(() -> new RuntimeException("Mission not found"));

        if(!m.isCompleted()) {
            m.setCompleted(true);
            p.setScore(p.getScore() + m.getPoints());

            if(m.getBadge() != null && !p.getBadges().contains(m.getBadge())) {
                p.getBadges().add(m.getBadge());
            }

            boolean allComplete = p.getMissions().stream().allMatch(Mission::isCompleted);
            if(allComplete) {
                p.setLevel(p.getLevel() + 1);

                Mission newM = Mission.builder()
                        .id("lvl" + p.getLevel() + "-1")
                        .title("Livello " + p.getLevel() + " - Missione 1")
                        .description("Missione generata automaticamente!")
                        .points(20)
                        .completed(false)
                        .badge("Badge Livello " + p.getLevel())
                        .build();
                p.getMissions().add(newM);
            }
        }
        return progRepo.save(p);
    }
}


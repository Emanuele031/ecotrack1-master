package it.epicode.ecotrack.services;

import it.epicode.ecotrack.entities.Mission;
import it.epicode.ecotrack.entities.Progress;
import it.epicode.ecotrack.repositories.ProgressRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.ArrayList;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@SpringBootTest
public class ProgressServiceTest {

    @Mock
    private ProgressRepository progressRepo;

    @InjectMocks
    private ProgressService progressService;

    @BeforeEach
    void setup() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void completeMission_shouldIncreaseScoreAndGenerateNewMissionIfAllComplete() {
        Progress p = Progress.builder().id(1L).level(1).score(0).missions(new ArrayList<>()).build();
        Mission m = Mission.builder().id("m1").points(10).completed(false).build();
        p.getMissions().add(m);

        when(progressRepo.findById(1L)).thenReturn(Optional.of(p));
        when(progressRepo.save(any(Progress.class))).thenReturn(p);

        Progress result = progressService.completeMission(1L, "m1");

        assertEquals(10, result.getScore());
        assertTrue(result.getMissions().get(0).isCompleted());
        verify(progressRepo, times(1)).save(any(Progress.class));
    }
}


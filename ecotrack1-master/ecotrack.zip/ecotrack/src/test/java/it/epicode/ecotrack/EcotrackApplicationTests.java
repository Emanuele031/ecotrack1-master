package it.epicode.ecotrack;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EcotrackApplicationTests {

	@Test
	void contextLoads() {
	}

}
